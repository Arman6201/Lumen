package com.lumen.gallery

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer

// Fixed palette (no Material You / dynamic colour). Light = Apple Photos feel, dark = true black.
@Immutable
data class LumenColors(
    val bg: Color,
    val surface: Color,
    val text: Color,
    val secondary: Color,
    val accent: Color,
    val bar: Color,
    val danger: Color,
)

private val Light = LumenColors(
    bg = Color.White,
    surface = Color(0xFFF2F2F7),
    text = Color(0xFF111114),
    secondary = Color(0xFF8A8A91),
    accent = Color(0xFF2F6BFF),
    bar = Color(0xF2F6F6F9),
    danger = Color(0xFFFF3B30),
)

private val Dark = LumenColors(
    bg = Color.Black,
    surface = Color(0xFF1C1C1E),
    text = Color(0xFFF5F5F7),
    secondary = Color(0xFF8E8E93),
    accent = Color(0xFF5B8CFF),
    bar = Color(0xF21C1C1E),
    danger = Color(0xFFFF453A),
)

val LocalLumen = staticCompositionLocalOf { Light }

@Composable
fun LumenTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLumen provides if (isSystemInDarkTheme()) Dark else Light) {
        content()
    }
}

/** iOS-style tap: no ripple, springy press-in scale. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}
